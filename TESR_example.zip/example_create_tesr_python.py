#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 08:32:06 2018

@author: dcp99
"""


#%%

import numpy as np
#import copy
import matplotlib.pyplot as plt
from hexrd.xrd import rotations as rot
import scipy.io as sio    

#%%
#LOAD DATA
data=np.load(open('/directory/example_HEDM_map.npz','rb'))  #data is already modified to be ORTHOGONAL TO THE ARRAY
grain_map = data['example_grain_map']
Xs = data['example_Xs']
Ys = data['example_Ys']
Zs = data['example_Zs']
#VOXEL SPACING
voxel_spacing = 0.005
#SAVE FILE NAME
file_name='example_data'

#%%
#CREATE ASSEMBLED DATA -- LIST OF [VOXEL COORDINATES (X,Y,Z),GRAIN ID]

coordinate_list=np.vstack((Xs.ravel(),Ys.ravel(),Zs.ravel()))
assembled_data=np.hstack((coordinate_list.T,np.atleast_2d(grain_map.ravel()).T))

#%% SORT BY ROWS Z AND THEN Y

assembled_data=assembled_data[assembled_data[:,2].argsort()]
total_size=grain_map.shape[0]*grain_map.shape[1]*grain_map.shape[2]

stack_size=grain_map.shape[0]*grain_map.shape[1]
for ii in np.arange(total_size/stack_size):
     tmp_args=assembled_data[ii*stack_size:(ii+1)*stack_size,1].argsort()
     assembled_data[ii*stack_size:(ii+1)*stack_size,:]=assembled_data[ii*stack_size+tmp_args,:]
     
stack_size=grain_map.shape[1]
for ii in np.arange(total_size/stack_size):
     tmp_args=assembled_data[ii*stack_size:(ii+1)*stack_size,0].argsort()
     assembled_data[ii*stack_size:(ii+1)*stack_size,:]=assembled_data[ii*stack_size+tmp_args,:]

#%%

np.set_printoptions(threshold=np.inf)
l1  = '***tesr'
l2  = ' **format'
l3  = '   2.0 ascii'
l4  = ' **general'
l5  = '   3'
l6  = '   ' + str(grain_map.shape[1]) + ' ' + str(grain_map.shape[0])  + ' ' + str(grain_map.shape[2]) 
l7  = '   ' + str(voxel_spacing) + ' ' + str(voxel_spacing) + ' ' + str(voxel_spacing)
l8  = ' **cell';
l9  = '   ' + str(np.max(grain_map).astype('int'))
l10 = '  *id';
l11 = '   ' + str(np.arange(1,np.max(grain_map)+1).astype('int'))[1:-1]
l12 = ' **data'
#l13 = '   ' + str(assembled_data[:,3].astype('int'))[1:-1]
l14 = '***end'

#%%
output = open('/directory/%s.tesr'%(file_name),'w');
output.write('%s\n' % l1)
output.write('%s\n' % l2)
output.write('%s\n' % l3)
output.write('%s\n' % l4)
output.write('%s\n' % l5)
output.write('%s\n' % l6)
output.write('%s\n' % l7)
output.write('%s\n' % l8)
output.write('%s\n' % l9)
output.write('%s\n' % l10)
output.write('%s\n' % l11)
output.write('%s\n' % l12)
output.write('   ')
np.savetxt(output,np.atleast_2d(assembled_data[:,3]).T,fmt='%d')
#output.write('%s\n' % l13)
output.write('%s\n' % l14)

output.close()
        
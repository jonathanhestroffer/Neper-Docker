#!/bin/bash

# Create tessellation
neper -T -n from_morpho -domain "cube(0.5,0.5,0.5)" -morpho "tesr:file(example_tesr.tesr)" -morphooptiobj "pts(region=surf,res=7)" -morphooptistop itermax=30 -reg 1 -o example_tess

# Visualize tesr
neper -V example_tesr.tesr -datacellcol id -imagesize 600:600 -cameracoo 3:3:2.2 -cameralookat 0.5:0.5:0.35 -print example_tesr

# Visualize tessellation
neper -V example_tess.tess -datacellcol id -imagesize 600:600 -cameracoo 3:3:2.2 -cameralookat 0.5:0.5:0.35 -print example_tess

# Mesh tessellation
neper -M example_tess.tess -part 32:8 -for msh,fepx -order 2 -faset z0,z1,x0,x1,y0,y1

# Visualize mesh
neper -V example_mesh.msh -showelt1d all -dataelset3dcol id -dataelt1drad 0.0025 -dataelt3dedgerad 0.0025 -imagesize 600:600 -cameracoo 3:3:2.2 -cameralookat 0.5:0.5:0.3 -print example_mesh

# Get Voronoi statistics
neper -T -loadtess example_tess.tess -statcell vol,x,y,z -o example_tess

exit 0

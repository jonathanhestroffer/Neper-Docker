function generate_tesr

% Load data, specify voxel size
load('I.mat');
numvox = size(I,1);
voxedge = 1/numvox;

% Create meshed grid for data points (centers of voxels)
x = voxedge/2:voxedge:1-voxedge/2;
y = voxedge/2:voxedge:1-voxedge/2;
z = voxedge/2:voxedge:51*voxedge-voxedge/2;
[X,Y,Z] = meshgrid(x,y,z);

% Check for unique values, renumber;
data = I;
curgr = unique(I);
expgr = 0:max(curgr);
delvals = setdiff(expgr,curgr);
dels = length(delvals);
while dels > 0
    val = delvals(1);
    TF = data > val;
    data(TF) = data(TF) - 1;
    curgr = unique(data);
    expgr = 0:max(curgr);
    delvals = setdiff(expgr,curgr);
    dels = length(delvals);
end
numgr = max(max(max(data)));
datavec = reshape(data,prod(size(data)),1);
X = reshape(X,prod(size(X)),1);
Y = reshape(Y,prod(size(X)),1);quat
Z = reshape(Z,prod(size(X)),1);
crdvals = [X,Y,Z,datavec];
crdvals = sortrows(crdvals,[3 2]);
datavec = crdvals(:,4)';
% datavec = datavec+1;

% Write tesr file for neper
l1  = '***tesr';
l2  = ' **format';
l3  = '   2.0 ascii';
l4  = ' **general';
l5  = '   3';
l6  = ['   ',num2str(size(data))];
l7  = ['   ',num2str(voxedge),' ',num2str(voxedge),' ',num2str(voxedge)];
l8  = ' **cell';
l9  = ['   ',num2str(max(datavec))];
l10 = '  *id';
l11 = ['   ',num2str(1:max(datavec))];
l12  = ' **data';
l13  = ['   ',num2str(datavec)];
l14 = '***end';
fileid = fopen(['example_matlab-produced.tesr'],'w');
fprintf(fileid,'%s\n',l1);
fprintf(fileid,'%s\n',l2);
fprintf(fileid,'%s\n',l3);
fprintf(fileid,'%s\n',l4);
fprintf(fileid,'%s\n',l5);
fprintf(fileid,'%s\n',l6);
fprintf(fileid,'%s\n',l7);
fprintf(fileid,'%s\n',l8);
fprintf(fileid,'%s\n',l9);
fprintf(fileid,'%s\n',l10);
fprintf(fileid,'%s\n',l11);
fprintf(fileid,'%s\n',l12);
fprintf(fileid,'%s\n',l13);
fprintf(fileid,'%s\n',l14);

end

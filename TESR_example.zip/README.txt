Folder contents:
- HEDM example (.npz file) which contains a segmented grain map with integer grain identification numbers, and coordinate maps.
- Example scripts for creating tesr files from 3D maps saved as array data using python or matlab. (.py and .m)
- Example neper scripts for tesselating from near-field data. (.sh file)
- Romain's 2018 paper (this work corresponds to section 5) (.pdf)

NOTE: The python script provided was used to generate the tesr file for neper for these data. The matlab script is from one of our colleagues who has used matlab to produce these files from near-field data in the past. I have not tried using it for this dataset.

Based on discussions with Romain, the general instructions are as follows: 

1. Generate a .tesr file from the voxelated data (see "create_tesr" scripts for examples and Neper documentation for details)
	Notes on this: 
		a. The data domain (shape/dimensions in 3D) for Neper will be very important. If you are working with a cubic sample, the faces of the array should correspond to the faces of the sample. In other words, the array used to generate the tesr should be orthogonal to the x,y,z axis.

2. Use Neper -morpho commands. An example from Romain Quey is below: 

Generating a sample tesr to work with:
- neper -T -n 10 -morpho gg -o n10

Fitting the tesr:
- [clean up the tesr]*
- neper -T -morpho "tesr:file(n10.tesr)" -domain "cube(1,1,1)"

*Once it is done, it may be desirable to clean up the tesr to ease
-morpho --- it works better if the tesr exactly fits the domain before
-morpho is run.  This can be done by passing the tesr through -transform
"grow,tessinter(a_tess_built_using_the_correct_domain)".

Then, -morpho runs quite quick (much more than for the far-field case).


3. Iterate until happy with tessellation prior to meshing. 